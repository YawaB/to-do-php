<?php
 $cnx=mysqli_connect('localhost','root','','todo') or die("connection failed !");

?>